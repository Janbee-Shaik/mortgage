/**
 * 
 */
package com.star.mortgage.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.star.mortgage.dto.CustomerDto;
import com.star.mortgage.dto.ResponseDto;
import com.star.mortgage.entity.Customer;
import com.star.mortgage.repository.CustomerRepository;
import com.star.mortgage.utility.ErrorConstants;

/**
 * @author User1
 *
 */
@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	CustomerRepository customerRepository;

	@Override
	public ResponseDto customerLogin(CustomerDto customerDto) {

		ResponseDto responseDto = new ResponseDto();

		if (customerDto.getLoginId().isEmpty() || customerDto.getPassword().isEmpty()) {
			responseDto.setStatusCode(ErrorConstants.INVALID_INPUT_CODE);
			responseDto.setStatusMessage(ErrorConstants.INVALID_INPUT);

		} else {
			Customer customer = customerRepository.findByLoginIdAndPassword(customerDto.getLoginId(),
					customerDto.getPassword());

			if (customer != null) {
				responseDto.setStatusCode(ErrorConstants.LOGIN_SUCCESS_CODE);
				responseDto.setStatusMessage(ErrorConstants.LOGIN_SUCCESS);
			} else {
				responseDto.setStatusCode(ErrorConstants.LOGIN_FAIL_CODE);
				responseDto.setStatusMessage(ErrorConstants.LOGIN_FAIL);

			}
		}
		return responseDto;
	}

}
