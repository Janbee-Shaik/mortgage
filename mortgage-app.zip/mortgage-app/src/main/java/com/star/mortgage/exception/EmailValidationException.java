/**
 * 
 */
package com.star.mortgage.exception;

/**
 * @author User1
 *
 */
public class EmailValidationException extends Exception {
	
	private static final long serialVersionUID = -1747502351308293745L;

	public EmailValidationException(String message) {
		super(message);
	}

}
