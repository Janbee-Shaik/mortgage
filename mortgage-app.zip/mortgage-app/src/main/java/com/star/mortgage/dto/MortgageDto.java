/**
 * 
 */
package com.star.mortgage.dto;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Getter;
import lombok.Setter;

/**
 * @author Nagajyoti
 *
 */
@Getter
@Setter
public class MortgageDto {

	private String firstName;
	private String lastName;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd/MM/yyyy")  
	private LocalDate dob;
	private String phoneNumber;
	private String email;
	private String panCard;
	private String occupation;
	private Double salary;
	private String propertyType;
	private Double propertyCost;
	private Double deposit;
	private String employmentStatus;
	
	private int tenure;

}
