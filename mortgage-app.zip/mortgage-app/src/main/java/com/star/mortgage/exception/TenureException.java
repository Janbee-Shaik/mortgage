/**
 * 
 */
package com.star.mortgage.exception;

/**
 * @author User1
 *
 */
public class TenureException extends Exception{
	
	private static final long serialVersionUID = -1747502351308293745L;

	public TenureException(String message) {
		super(message);
	}

}
