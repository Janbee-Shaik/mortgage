/**
 * 
 */
package com.star.mortgage.exception;

public class PropertyCostException extends Exception {

	private static final long serialVersionUID = -1747502351308293745L;

	public PropertyCostException(String message) {
		super(message);
	}
}
