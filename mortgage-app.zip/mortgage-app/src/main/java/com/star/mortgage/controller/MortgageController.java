/**
 * 
 */
package com.star.mortgage.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.star.mortgage.dto.MortgageDetailsDto;
import com.star.mortgage.dto.MortgageDto;
import com.star.mortgage.exception.AgeValidException;
import com.star.mortgage.exception.EmailValidationException;
import com.star.mortgage.exception.EmiException;
import com.star.mortgage.exception.PhoneNumberException;
import com.star.mortgage.exception.PropertyCostException;
import com.star.mortgage.exception.TenureException;
import com.star.mortgage.exception.UserExistException;
import com.star.mortgage.service.MortgageService;
import com.star.mortgage.service.MortgageServiceImpl;

/**
 * @author User1
 *
 */

@RestController
public class MortgageController {

	@Autowired
	MortgageService mortgageService;

	private static final Logger LOGGER = LoggerFactory.getLogger(MortgageServiceImpl.class);

	/**
	 * @param mortgageDto
	 * @return loginId , password ,mortageAccount,SavingsAccount
	 * @throws PropertyCostException
	 * @throws PhoneNumberException
	 * @throws EmailValidationException
	 * @throws AgeValidException
	 * @throws TenureException
	 * @throws EmiException
	 * @throws UserExistException
	 */
	@PostMapping("/mortgage")
	public ResponseEntity<MortgageDetailsDto> mortgageRegister(@RequestBody MortgageDto mortgageDto)
			throws PropertyCostException, PhoneNumberException, EmailValidationException, AgeValidException,
			TenureException, EmiException, UserExistException {
		MortgageDetailsDto response = mortgageService.mortgageRegister(mortgageDto);
		return new ResponseEntity<>(response, HttpStatus.CREATED);

	}

}
