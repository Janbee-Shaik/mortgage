/**
 * 
 */
package com.star.mortgage.utility;

/**
 * @author User1
 *
 */
public class ErrorConstants {
	
	
	public static final String PROPERTY_COST_VALIDATION_MESSAGE = "Property Cost should be Minimum 100000 or Deposit should be minimun 20% of property cost";
	public static final int PROPERTY_COST_VALIDATION_MESSAGE_CODE = 601;


	public static final String PHONE_VALIDATION_MESSAGE = "Please Enter Valid Phone Number.";
	public static final int PHONE_VALIDATION_MESSAGE_CODE = 603;
	
	public static final String EMAIL_VALIDATION_MESSAGE = "Please Enter Valid Email.";
	public static final int EMAIL_VALIDATION_MESSAGE_CODE = 604;
	
	public static final String CUSTOMER_AGE_MINIMUM_MESSAGE = "You are not eligible for this Loan age should be >21";
	public static final int CUSTOMER_AGE_MINIMUM_MESSAGE_CODE = 605;
	
	public static final String TENURE_MINIMUM_MESSAGE = "Tenure should be greater then 0";
	public static final int TENURE_MINIMUM_MESSAGE_CODE = 606;
	
	public static final String TRANSACTIONAL_ACCOUNT_SUFFIX = "ACC";
	public static final String TRANSACTION_ACCOUNT = "Savings Account";
	
	public static final String MORTGAGE_ACCOUNT_SUFFIX = "MORT";
	public static final String MORTAGE_ACCOUNT = "Mortgage Account";
	
	public static final String MORTGAGE_SUCCESS = "Congradulations, your mortage has been generated";
	public static final int MORTGAGE_SUCCESS_CODE = 201;


	public static final String EMI_MESSAGE = "Salary is less then 80% of emi";
	public static final int EMI_MESSAGE_CODE = 604;


	public static final String INVALID_ACCOUNT="invalid account number";
	public static final int INVALID_ACCOUNT_CODE=600;
	
	public static final String NO_LOAN_RECORD="no transactions done";
	public static final int NO_LOAN_RECORD_CODE=601;
	
	public static final String NO_RECORD_FOUND="customer id not found";
	public static final int NO_RECORD_FOUND_CODE=602;
	
	
	public static final String NOT_APPLIED="not applied for any loan";
	public static final int NO_APPLIED_CODE=602;
	
	public static final String PAID_SUCCESS="paid successfully";
	public static final int PAID_SUCCESS_CODE=603;
	
	public static final String CUSTOMER_EXIST="Mortage already generated with same email";
	public static final int CUSTOMER_EXIST_CODE=603;
	
	  public static final String NO_RECORDS_FOUND = "no record found";
	    public static final int NO_RECORDS_FOUND_CODE = 600;

	 

	    public static final String NO_ID_FOUND = "no customerid found";
	    public static final int NO_ID_FOUND_CODE = 601;
	    
	    public static final String INVALID_INPUT = "Please provide the required  data";
	    public static final int INVALID_INPUT_CODE = 602;

	 

	    public static final String LOGIN_SUCCESS = "logged in successfully";
	    public static final int LOGIN_SUCCESS_CODE = 603;

	 

	    public static final String LOGIN_FAIL = "invalid username or password";
	    public static final int LOGIN_FAIL_CODE = 604;
	    
	    public static final String PLEASE_FIND_ACCOUNT_DETAILS = "please find account details";
	    public static final int PLEASE_FIND_ACCOUNT_DETAILSCODE = 605;
	    
	    public static final String ACCOUNT_NOT_FOUND = "account not found ";
	    public static final int ACCOUNT_NOT_FOUND_CODE = 606;
	    
	    public static final String MORTGAGE_NOT_GENERATED = "Mortage has not been generated for this customer id";
	




}
