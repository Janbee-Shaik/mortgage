/**
 * 
 */
package com.star.mortgage.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.star.mortgage.dto.AccountSummaryDto;
import com.star.mortgage.dto.CustomerDto;
import com.star.mortgage.dto.ResponseDto;
import com.star.mortgage.service.CustomerService;

/**
 * @author User1
 *
 */
@RestController
public class CustomerController {

	@Autowired
	CustomerService customerService;

	/**
	 * This method is used to check the login details of the customer
	 * 
	 * @author Manideepika
	 * @since 2020-03-23
	 * @param emailId  -Here we use loginId to check the username correct or not
	 * @param password -Here we use password to check the password correct or not
	 * @return ResponseEntity Object along with status code and success login
	 *         message
	 * 
	 */
	@PostMapping("/login")
	public ResponseEntity<ResponseDto> customerLogin(@RequestBody CustomerDto customerDto) {
		ResponseDto responseDto = customerService.customerLogin(customerDto);
		return new ResponseEntity<>(responseDto, HttpStatus.OK);
	}

}
