/**
 * 
 */
package com.star.mortgage.dto;

import lombok.Getter;
import lombok.Setter;

/**
 * @author User1
 *
 */
@Getter
@Setter
public class MortgageDetailsDto {

	private String transactionAccountNumber;
	private String mortgageAccountNumber;
	private String loginId;
	private String password;
	private Integer statusCode;
	private String message;

}
