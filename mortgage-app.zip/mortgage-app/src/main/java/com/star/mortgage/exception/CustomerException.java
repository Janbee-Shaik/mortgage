package com.star.mortgage.exception;

public class CustomerException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CustomerException(String arg0) {
		super(arg0);
		
	}
	

}
