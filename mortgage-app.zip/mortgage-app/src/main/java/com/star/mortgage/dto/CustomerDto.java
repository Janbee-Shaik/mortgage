/**
 * 
 */
package com.star.mortgage.dto;

import lombok.Getter;
import lombok.Setter;

/**
 * @author User1
 *
 */
@Setter
@Getter
public class CustomerDto {

	private String loginId;
	private String password;

}
