/**
 * 
 */
package com.star.mortgage.service;

import com.star.mortgage.dto.CustomerDto;
import com.star.mortgage.dto.ResponseDto;

/**
 * @author User1
 *
 */
public interface CustomerService {

	/**
	 * @param customerDto
	 * @return
	 */
	public ResponseDto customerLogin(CustomerDto customerDto);

}
